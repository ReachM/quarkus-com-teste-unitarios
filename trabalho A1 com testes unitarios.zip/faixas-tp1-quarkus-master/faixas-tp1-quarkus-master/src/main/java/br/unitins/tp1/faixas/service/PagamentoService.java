package br.unitins.tp1.faixas.service;

import br.unitins.tp1.faixas.dto.PagamentoRequestDTO;
import br.unitins.tp1.faixas.model.Pagamento;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class PagamentoService {

    @PersistenceContext
    EntityManager em;

    public Pagamento findById(Long id) {
        return em.find(Pagamento.class, id);
    }

    public List<Pagamento> findAll() {
        return em.createQuery("SELECT p FROM Pagamento p", Pagamento.class).getResultList();
    }

    @Transactional
    public Pagamento create(PagamentoRequestDTO dto) {
        Pagamento pagamento = new Pagamento();
        pagamento.setPedidoId(dto.getPedidoId());
        pagamento.setValor(dto.getValor());
        pagamento.setMetodo(dto.getMetodo());
        em.persist(pagamento);
        return pagamento;
    }

    @Transactional
    public void update(Long id, PagamentoRequestDTO dto) {
        Pagamento pagamento = em.find(Pagamento.class, id);
        pagamento.setPedidoId(dto.getPedidoId());
        pagamento.setValor(dto.getValor());
        pagamento.setMetodo(dto.getMetodo());
    }

    @Transactional
    public void delete(Long id) {
        Pagamento pagamento = em.find(Pagamento.class, id);
        em.remove(pagamento);
    }
}
