package br.unitins.tp1.faixas.resource;

import br.unitins.tp1.faixas.dto.FornecedorRequestDTO;
import br.unitins.tp1.faixas.model.Fornecedor;
import br.unitins.tp1.faixas.service.FornecedorService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("/fornecedores")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class FornecedorResource {

    @Inject
    FornecedorService fornecedorService;

    @GET
    @Path("/{id}")
    public Fornecedor findById(@PathParam("id") Long id) {
        return fornecedorService.findById(id);
    }

    @GET
    public List<Fornecedor> findAll() {
        return fornecedorService.findAll();
    }

    @POST
    public Fornecedor create(FornecedorRequestDTO fornecedor) {
        return fornecedorService.create(fornecedor);
    }

    @PUT
    @Path("/{id}")
    public void update(@PathParam("id") Long id, FornecedorRequestDTO fornecedor) {
        fornecedorService.update(id, fornecedor);
    }

    @DELETE
    @Path("/{id}")
    public void delete(@PathParam("id") Long id) {
        fornecedorService.delete(id);
    }
}
