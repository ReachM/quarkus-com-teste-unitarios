package br.unitins.tp1.faixas.service;

import br.unitins.tp1.faixas.dto.ClienteRequestDTO;
import br.unitins.tp1.faixas.model.Cliente;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class ClienteService {

    @PersistenceContext
    EntityManager em;

    public Cliente findById(Long id) {
        return em.find(Cliente.class, id);
    }

    public List<Cliente> findAll() {
        return em.createQuery("SELECT c FROM Cliente c", Cliente.class).getResultList();
    }

    public List<Cliente> findByNome(String nome) {
        return em.createQuery("SELECT c FROM Cliente c WHERE c.nome LIKE :nome", Cliente.class)
                 .setParameter("nome", "%" + nome + "%")
                 .getResultList();
    }

    @Transactional
    public Cliente create(ClienteRequestDTO dto) {
        Cliente cliente = new Cliente();
        cliente.setNome(dto.getNome());
        cliente.setEmail(dto.getEmail());
        em.persist(cliente);
        return cliente;
    }

    @Transactional
    public void update(Long id, ClienteRequestDTO dto) {
        Cliente cliente = em.find(Cliente.class, id);
        cliente.setNome(dto.getNome());
        cliente.setEmail(dto.getEmail());
    }

    @Transactional
    public void delete(Long id) {
        Cliente cliente = em.find(Cliente.class, id);
        em.remove(cliente);
    }
}
