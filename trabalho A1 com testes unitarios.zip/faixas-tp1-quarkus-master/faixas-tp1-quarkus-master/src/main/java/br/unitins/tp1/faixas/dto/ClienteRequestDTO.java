package br.unitins.tp1.faixas.dto;

public class ClienteRequestDTO {
    private String nome;
    private String email;

    
}
