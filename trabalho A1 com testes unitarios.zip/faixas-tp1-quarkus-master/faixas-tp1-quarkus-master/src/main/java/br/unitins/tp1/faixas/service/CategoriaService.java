package br.unitins.tp1.faixas.service;

import br.unitins.tp1.faixas.dto.CategoriaRequestDTO;
import br.unitins.tp1.faixas.model.Categoria;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class CategoriaService {

    @PersistenceContext
    EntityManager em;

    public Categoria findById(Long id) {
        return em.find(Categoria.class, id);
    }

    public List<Categoria> findAll() {
        return em.createQuery("SELECT c FROM Categoria c", Categoria.class).getResultList();
    }

    @Transactional
    public Categoria create(CategoriaRequestDTO dto) {
        Categoria categoria = new Categoria();
        categoria.setNome(dto.getNome());
        em.persist(categoria);
        return categoria;
    }

    @Transactional
    public void update(Long id, CategoriaRequestDTO dto) {
        Categoria categoria = em.find(Categoria.class, id);
        categoria.setNome(dto.getNome());
    }

    @Transactional
    public void delete(Long id) {
        Categoria categoria = em.find(Categoria.class, id);
        em.remove(categoria);
    }
}
