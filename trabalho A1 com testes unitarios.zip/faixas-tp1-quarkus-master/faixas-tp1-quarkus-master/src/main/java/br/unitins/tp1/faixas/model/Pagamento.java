package br.unitins.tp1.faixas.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Pagamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long pedidoId; // ID do pedido relacionado
    private double valor;
    private String metodo; // Ex: Cartão, Boleto

    
}
