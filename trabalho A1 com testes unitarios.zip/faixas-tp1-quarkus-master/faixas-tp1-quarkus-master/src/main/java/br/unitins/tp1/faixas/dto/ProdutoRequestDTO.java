package br.unitins.tp1.faixas.dto;

public class ProdutoRequestDTO {
    private String nome;
    private double preco;

    
}
