package br.unitins.tp1.faixas.dto;

public class PedidoRequestDTO {
    private String descricao;

   
}
