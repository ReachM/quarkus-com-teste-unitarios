package br.unitins.tp1.categoria.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.categoria.dto.CategoriaRequestDTO;
import br.unitins.tp1.categoria.model.Categoria;
import br.unitins.tp1.categoria.service.CategoriaService;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;

@QuarkusTest
public class CategoriaResourceTest {

    @Inject
    CategoriaService categoriaService;

    @Test
    public void testFindById() {
        given()
            .when().get("/categorias/1")
            .then().statusCode(200)
            .body("id", is(1));
    }

    @Test
    public void testFindAll() {
        given()
            .when().get("/categorias")
            .then().statusCode(200);
    }

    @Test
    public void testCreate() {
        CategoriaRequestDTO dto = new CategoriaRequestDTO("Categoria Teste");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/categorias")
            .then()
                .statusCode(201)
                .body("nome", is("Categoria Teste"));

        // Limpa o dado criado
        categoriaService.delete(categoriaService.findByNome("Categoria Teste").getId());
    }

    @Test
    public void testUpdate() {
        CategoriaRequestDTO dto = new CategoriaRequestDTO("Categoria Teste");
        long id = categoriaService.create(dto).getId();

        CategoriaRequestDTO novoDto = new CategoriaRequestDTO("Categoria Atualizada");

        given()
            .contentType(ContentType.JSON)
            .body(novoDto)
            .when()
                .put("/categorias/" + id)
            .then()
                .statusCode(204);

        Categoria categoria = categoriaService.findById(id);

        assertEquals(categoria.getNome(), "Categoria Atualizada");

        categoriaService.delete(id);
    }

    @Test
    public void testDelete() {
        CategoriaRequestDTO dto = new CategoriaRequestDTO("Categoria Teste");
        Long id = categoriaService.create(dto).getId();

        given()
            .when()
                .delete("/categorias/" + id)
            .then().statusCode(204);

        Categoria categoria = categoriaService.findById(id);
        assertNull(categoria);
    }
}
