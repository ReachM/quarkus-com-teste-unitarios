package br.unitins.tp1.cliente.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.cliente.dto.ClienteRequestDTO;
import br.unitins.tp1.cliente.model.Cliente;
import br.unitins.tp1.cliente.service.ClienteService;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;

@QuarkusTest
public class ClienteResourceTest {

    @Inject
    ClienteService clienteService;

    @Test
    public void testFindById() {
        given()
            .when().get("/clientes/1")
            .then().statusCode(200)
            .body("id", is(1));
    }

    @Test
    public void testFindAll() {
        given()
            .when().get("/clientes")
            .then().statusCode(200);
    }

    @Test
    public void testCreate() {
        ClienteRequestDTO dto = new ClienteRequestDTO("Cliente Teste", "email@test.com");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/clientes")
            .then()
                .statusCode(201)
                .body("nome", is("Cliente Teste"));

        // Limpa o dado criado
        clienteService.delete(clienteService.findByNome("Cliente Teste").getId());
    }

    @Test
    public void testUpdate() {
        ClienteRequestDTO dto = new ClienteRequestDTO("Cliente Teste", "email@test.com");
        long id = clienteService.create(dto).getId();

        ClienteRequestDTO novoDto = new ClienteRequestDTO("Cliente Atualizado", "novoemail@test.com");

        given()
            .contentType(ContentType.JSON)
            .body(novoDto)
            .when()
                .put("/clientes/" + id)
            .then()
                .statusCode(204);

        Cliente cliente = clienteService.findById(id);

        assertEquals(cliente.getNome(), "Cliente Atualizado");
        assertEquals(cliente.getEmail(), "novoemail@test.com");

        clienteService.delete(id);
    }

    @Test
    public void testDelete() {
        ClienteRequestDTO dto = new ClienteRequestDTO("Cliente Teste", "email@test.com");
        Long id = clienteService.create(dto).getId();

        given()
            .when()
                .delete("/clientes/" + id)
            .then().statusCode(204);

        Cliente cliente = clienteService.findById(id);
        assertNull(cliente);
    }
}
