package br.unitins.tp1.pedido.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.pedido.dto.PedidoRequestDTO;
import br.unitins.tp1.pedido.model.Pedido;
import br.unitins.tp1.pedido.service.PedidoService;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;

@QuarkusTest
public class PedidoResourceTest {

    @Inject
    PedidoService pedidoService;

    @Test
    public void testFindById() {
        given()
            .when().get("/pedidos/1")
            .then().statusCode(200)
            .body("id", is(1));
    }

    @Test
    public void testFindAll() {
        given()
            .when().get("/pedidos")
            .then().statusCode(200);
    }

    @Test
    public void testCreate() {
        PedidoRequestDTO dto = new PedidoRequestDTO(1L, 2L, "2024-01-01");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/pedidos")
            .then()
                .statusCode(201)
                .body("data", is("2024-01-01"));

        // Limpa o dado criado
        pedidoService.delete(pedidoService.findByData("2024-01-01").getId());
    }

    @Test
    public void testUpdate() {
        PedidoRequestDTO dto = new PedidoRequestDTO(1L, 2L, "2024-01-01");
        long id = pedidoService.create(dto).getId();

        PedidoRequestDTO novoDto = new PedidoRequestDTO(1L, 2L, "2024-12-01");

        given()
            .contentType(ContentType.JSON)
            .body(novoDto)
            .when()
                .put("/pedidos/" + id)
            .then()
                .statusCode(204);

        Pedido pedido = pedidoService.findById(id);

        assertEquals(pedido.getData(), "2024-12-01");

        pedidoService.delete(id);
    }

    @Test
    public void testDelete() {
        PedidoRequestDTO dto = new PedidoRequestDTO(1L, 2L, "2024-01-01");
        Long id = pedidoService.create(dto).getId();

        given()
            .when()
                .delete("/pedidos/" + id)
            .then().statusCode(204);

        Pedido pedido = pedidoService.findById(id);
        assertNull(pedido);
    }
}
