package br.unitins.tp1.pagamento.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.pagamento.dto.PagamentoRequestDTO;
import br.unitins.tp1.pagamento.model.Pagamento;
import br.unitins.tp1.pagamento.service.PagamentoService;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;

@QuarkusTest
public class PagamentoResourceTest {

    @Inject
    PagamentoService pagamentoService;

    @Test
    public void testFindById() {
        given()
            .when().get("/pagamentos/1")
            .then().statusCode(200)
            .body("id", is(1));
    }

    @Test
    public void testFindAll() {
        given()
            .when().get("/pagamentos")
            .then().statusCode(200);
    }

    @Test
    public void testCreate() {
        PagamentoRequestDTO dto = new PagamentoRequestDTO(500.0, "Cartão de Crédito");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/pagamentos")
            .then()
                .statusCode(201)
                .body("valor", is(500.0))
                .body("metodo", is("Cartão de Crédito"));

        // Limpa o dado criado
        pagamentoService.delete(pagamentoService.findByMetodo("Cartão de Crédito").getId());
    }

    @Test
    public void testUpdate() {
        PagamentoRequestDTO dto = new PagamentoRequestDTO(500.0, "Cartão de Crédito");
        long id = pagamentoService.create(dto).getId();

        PagamentoRequestDTO novoDto = new PagamentoRequestDTO(700.0, "Débito");

        given()
            .contentType(ContentType.JSON)
            .body(novoDto)
            .when()
                .put("/pagamentos/" + id)
            .then()
                .statusCode(204);

        Pagamento pagamento = pagamentoService.findById(id);

        assertEquals(pagamento.getValor(), 700.0);
        assertEquals(pagamento.getMetodo(), "Débito");

        pagamentoService.delete(id);
    }

    @Test
    public void testDelete() {
        PagamentoRequestDTO dto = new PagamentoRequestDTO(500.0, "Cartão de Crédito");
        Long id = pagamentoService.create(dto).getId();

        given()
            .when()
                .delete("/pagamentos/" + id)
            .then().statusCode(204);

        Pagamento pagamento = pagamentoService.findById(id);
        assertNull(pagamento);
    }
}
