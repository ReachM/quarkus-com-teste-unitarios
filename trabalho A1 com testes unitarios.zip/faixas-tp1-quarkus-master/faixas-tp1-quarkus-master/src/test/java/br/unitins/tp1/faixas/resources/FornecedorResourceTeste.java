package br.unitins.tp1.fornecedor.resource;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

import br.unitins.tp1.fornecedor.dto.FornecedorRequestDTO;
import br.unitins.tp1.fornecedor.model.Fornecedor;
import br.unitins.tp1.fornecedor.service.FornecedorService;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.http.ContentType;
import jakarta.inject.Inject;

@QuarkusTest
public class FornecedorResourceTest {

    @Inject
    FornecedorService fornecedorService;

    @Test
    public void testFindById() {
        given()
            .when().get("/fornecedores/1")
            .then().statusCode(200)
            .body("id", is(1));
    }

    @Test
    public void testFindAll() {
        given()
            .when().get("/fornecedores")
            .then().statusCode(200);
    }

    @Test
    public void testCreate() {
        FornecedorRequestDTO dto = new FornecedorRequestDTO("Fornecedor Teste", "fornecedor@teste.com");

        given()
            .contentType(ContentType.JSON)
            .body(dto)
            .when()
                .post("/fornecedores")
            .then()
                .statusCode(201)
                .body("nome", is("Fornecedor Teste"))
                .body("email", is("fornecedor@teste.com"));

        // Limpa o dado criado
        fornecedorService.delete(fornecedorService.findByNome("Fornecedor Teste").getId());
    }

    @Test
    public void testUpdate() {
        FornecedorRequestDTO dto = new FornecedorRequestDTO("Fornecedor Teste", "fornecedor@teste.com");
        long id = fornecedorService.create(dto).getId();

        FornecedorRequestDTO novoDto = new FornecedorRequestDTO("Fornecedor Atualizado", "atualizado@teste.com");

        given()
            .contentType(ContentType.JSON)
            .body(novoDto)
            .when()
                .put("/fornecedores/" + id)
            .then()
                .statusCode(204);

        Fornecedor fornecedor = fornecedorService.findById(id);

        assertEquals(fornecedor.getNome(), "Fornecedor Atualizado");
        assertEquals(fornecedor.getEmail(), "atualizado@teste.com");

        fornecedorService.delete(id);
    }

    @Test
    public void testDelete() {
        FornecedorRequestDTO dto = new FornecedorRequestDTO("Fornecedor Teste", "fornecedor@teste.com");
        Long id = fornecedorService.create(dto).getId();

        given()
            .when()
                .delete("/fornecedores/" + id)
            .then().statusCode(204);

        Fornecedor fornecedor = fornecedorService.findById(id);
        assertNull(fornecedor);
    }
}
